G51FSE Coursework
Names: Qingqi Shi & Yinfeng Xie

To run the game, execute 'GalacticWar.py' with Python runtime.

Controls:

Player ship (blue) always faces your mouse.
Hold right mouse button to accelerate player ship.
Release right mouse button to decellerate player ship.
Press or Hold left mouse button to fire bullets.

Hotkeys:

Esc - Pause game
R - Instant restart game
A - Toggle auto-shoot option

Aim:

Avoid enemy bullets and try to shoot red ships. Aim for higher score.